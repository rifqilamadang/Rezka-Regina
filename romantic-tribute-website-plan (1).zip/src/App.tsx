import { useState, useEffect, useRef, useMemo } from 'react';

const PHOTOS = [
  {
    url: 'https://i.ibb.co.com/rfs5L97M/IMG-20260502-WA0016.jpg',
    alt: 'Rezka Regina dengan kebaya cream',
    caption: 'Yang ini saya simpan paling lama. Tenang, tapi bikin saya tidak tenang'
  },
  {
    url: 'https://i.ibb.co.com/5g469gHh/IMG-20260507-WA0024.jpg',
    alt: 'Rezka dengan sweater merah',
    caption: 'Merah favorit Sayang. Cocok. Berani, hangat, dan susah dilupakan'
  },
  {
    url: 'https://i.ibb.co.com/PGrSzm8x/IMG-20260526-213346-538.jpg',
    alt: 'Rezka mirror selfie',
    caption: 'Mirror selfie yang membuat saya memeriksa ulang: ini beneran mau sama saya?'
  },
  {
    url: 'https://i.ibb.co.com/v4FyxrBM/IMG-20260525-WA0045.jpg',
    alt: 'Rezka dengan roll rambut',
    caption: 'Absurdnya di sini. Roll di kepala, tapi tetap cantik. Ini bukti kekuatan Sayang'
  },
  {
    url: 'https://i.ibb.co.com/vxk06hSv/IMG-20260525-WA0055.jpg',
    alt: 'Rezka santai di kamar',
    caption: 'Versi santai. Yang sering saya lihat waktu teleponan sampai saya ketiduran'
  },
  {
    url: 'https://i.ibb.co.com/C3BfbCfF/IMG-20260525-WA0032.jpg',
    alt: 'Rezka bersama teman',
    caption: 'Sayang tidak sendirian. Ada yang menemani, ada yang menjaga. Saya bersyukur'
  },
  {
    url: 'https://i.ibb.co.com/whcqdZ3S/IMG-20260525-WA0024.jpg',
    alt: 'Rezka dengan ayah',
    caption: 'Ini yang paling saya kagumi. Pintu maaf tetap terbuka, meski tidak mudah'
  }
];

const PASSWORD = '10-10-1995';
const PASSWORD_ALT = '10101995';
const WA_NUMBER = '6281346386824';

const SONGS = [
  { id: 'O4_WQTvI7YQ', title: 'O4_WQTvI7YQ' },
  { id: 'pO3SgjYo90s', title: 'pO3SgjYo90s' },
  { id: 'D-VytLhH-KE', title: 'D-VytLhH-KE' },
  { id: 'JmCLgJ7VTGc', title: 'JmCLgJ7VTGc' },
  { id: 'qZIQAk-BUEc', title: 'qZIQAk-BUEc' },
  { id: 'IqGQ2mBn4BY', title: 'IqGQ2mBn4BY' },
];

export default function App() {
  const [unlocked, setUnlocked] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [activePhoto, setActivePhoto] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [currentSong, setCurrentSong] = useState<typeof SONGS[0] | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [songIndex, setSongIndex] = useState(0);
  const [showGift, setShowGift] = useState(false);
  const [giftAddress, setGiftAddress] = useState('');
  const [giftNote, setGiftNote] = useState('');
  const [noPos, setNoPos] = useState({ x: 0, y: 0 });
  const [noCount, setNoCount] = useState(0);
  const trackRef = useRef<HTMLDivElement>(null);
  const autoPlayRef = useRef<number | null>(null);
  const playerRef = useRef<any>(null);

  // Check session
  useEffect(() => {
    const saved = localStorage.getItem('rezka_unlocked');
    const savedSong = localStorage.getItem('rezka_song');
    const savedIndex = localStorage.getItem('rezka_song_index');
    if (saved === 'true') {
      setUnlocked(true);
      if (savedSong && savedIndex) {
        try {
          setCurrentSong(JSON.parse(savedSong));
          setSongIndex(parseInt(savedIndex));
          setIsPlaying(true);
        } catch {}
      } else {
        const idx = Math.floor(Math.random() * SONGS.length);
        setSongIndex(idx);
        setCurrentSong(SONGS[idx]);
        setIsPlaying(true);
        localStorage.setItem('rezka_song_index', idx.toString());
      }
    }
  }, []);

  // Particles - memoized to prevent re-render
  const particles = useMemo(() => 
    Array.from({ length: 24 }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 5,
      duration: 9 + Math.random() * 7,
      size: Math.random() > 0.75 ? 3 : 2,
    })), []
  );

  // Auto-play carousel
  useEffect(() => {
    if (!unlocked || isDragging) return;
    
    autoPlayRef.current = window.setInterval(() => {
      setActivePhoto((p) => (p + 1) % PHOTOS.length);
    }, 5500);
    
    return () => {
      if (autoPlayRef.current) clearInterval(autoPlayRef.current);
    };
  }, [unlocked, isDragging]);

  useEffect(() => {
    if (trackRef.current) {
      trackRef.current.style.transform = `translateX(-${activePhoto * 100}%)`;
    }
  }, [activePhoto]);

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = password.trim();
    if (clean === PASSWORD || clean === PASSWORD_ALT) {
      setIsTransitioning(true);
      // Pick random song
      const idx = Math.floor(Math.random() * SONGS.length);
      const randomSong = SONGS[idx];
      setSongIndex(idx);
      setCurrentSong(randomSong);
      setIsPlaying(true);
      setTimeout(() => {
        setUnlocked(true);
        localStorage.setItem('rezka_unlocked', 'true');
        localStorage.setItem('rezka_song', JSON.stringify(randomSong));
        localStorage.setItem('rezka_song_index', idx.toString());
      }, 400);
    } else {
      setError(true);
      setAttempts(a => a + 1);
      setPassword('');
      setTimeout(() => setError(false), 2200);
    }
  };

  // Touch handlers for swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    setIsDragging(true);
    setStartX(e.touches[0].clientX);
    if (autoPlayRef.current) clearInterval(autoPlayRef.current);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!isDragging) return;
    const diff = startX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        setActivePhoto((p) => (p + 1) % PHOTOS.length);
      } else {
        setActivePhoto((p) => (p - 1 + PHOTOS.length) % PHOTOS.length);
      }
    }
    setIsDragging(false);
  };

  // Scroll reveal
  useEffect(() => {
    if (!unlocked) return;
    
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [unlocked]);

  if (!unlocked) {
    return (
      <div className={`min-h-screen bg-[#0a0a0a] text-[#f0ebe5] relative overflow-hidden transition-opacity duration-700 ${isTransitioning ? 'opacity-0' : 'opacity-100'}`}>
        <style>{`
          @keyframes fall {
            0% { transform: translateY(-10px); opacity: 0; }
            10% { opacity: 0.7; }
            90% { opacity: 0.7; }
            100% { transform: translateY(100vh); opacity: 0; }
          }
          @keyframes pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.75; transform: scale(0.97); }
          }
          .reveal { opacity: 0; transform: translateY(16px); transition: opacity 0.8s ease, transform 0.8s ease; }
          .reveal.revealed { opacity: 1; transform: translateY(0); }
        `}</style>

        <div className="absolute inset-0 pointer-events-none">
          {particles.map((p) => (
            <div
              key={p.id}
              className="absolute bg-[#c0392b] rounded-full"
              style={{
                left: `${p.left}%`,
                top: '-10px',
                width: p.size,
                height: p.size,
                animation: `fall ${p.duration}s linear ${p.delay}s infinite`,
                opacity: 0.5,
              }}
            />
          ))}
        </div>

        <div className="relative z-10 min-h-screen flex items-center justify-center px-6">
          <div className="w-full max-w-[340px] text-center">
            <div className="mb-14" style={{ animation: 'pulse 3s ease-in-out infinite' }}>
              <div className="text-[44px] mb-6 leading-none">🔒</div>
              <h1 className="font-light tracking-[0.14em] text-[28px] sm:text-[32px] mb-2" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
                Hanya Untukmu
              </h1>
              <p className="text-[11px] tracking-[0.28em] text-[#888] uppercase" style={{ fontFamily: 'Space Mono, monospace' }}>
                Rezka Regina
              </p>
            </div>

            <p className="text-[14px] text-[#a8a8a8] font-light mb-12 leading-relaxed" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
              Halaman ini saya kunci. Bukan karena rahasia, tapi karena isinya hanya untuk satu orang: Sayang.
            </p>

            <form onSubmit={handleUnlock} className="space-y-7">
              <div>
                <label className="block text-[10px] tracking-[0.22em] text-[#666] uppercase mb-5" style={{ fontFamily: 'Space Mono, monospace' }}>
                  Masukkan tanggal lahir Sayang
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="10-10-1995"
                  className="w-full bg-transparent border-0 border-b border-[#922b21] text-center py-3.5 text-[17px] tracking-[0.28em] text-[#f0ebe5] placeholder-[#444] focus:outline-none focus:border-[#e74c3c] transition-colors"
                  style={{ fontFamily: 'Space Mono, monospace' }}
                  autoFocus
                  aria-label="Tanggal lahir"
                />
                <div className="h-[22px] mt-2.5 flex items-center justify-center">
                  <p className={`text-[11px] tracking-wide transition-opacity duration-300 ${error ? 'opacity-100 text-[#e74c3c]' : 'opacity-0'}`} style={{ fontFamily: 'Space Mono, monospace' }}>
                    {attempts >= 3 
                      ? 'Tenang, ini bukan untuk sembarang orang. Coba ingat lagi ya, Sayang.'
                      : 'Bukan yang saya tunggu. Coba lagi ya.'}
                  </p>
                </div>
              </div>

              <button
                type="submit"
                className="px-9 py-[11px] border border-[#922b21] text-[#e74c3c] hover:bg-[#c0392b] hover:text-white hover:border-[#c0392b] active:scale-[0.98] transition-all text-[11px] tracking-[0.18em] uppercase"
                style={{ fontFamily: 'Space Mono, monospace' }}
              >
                Buka
              </button>
            </form>

            <p className="mt-20 text-[10px] text-[#2a2a2a] tracking-[0.14em]" style={{ fontFamily: 'Space Mono, monospace' }}>
              — dibuat dengan tangan gemetar —
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#f0ebe5] antialiased selection:bg-[#c0392b]/30 selection:text-white">
      <style>{`
        html { scroll-behavior: smooth; }
        body { font-family: 'Cormorant Garamond', serif; }
        .mono { font-family: 'Space Mono', monospace; }
        .reveal { opacity: 0; transform: translateY(18px); transition: opacity 0.9s cubic-bezier(0.2,0,0,1), transform 0.9s cubic-bezier(0.2,0,0,1); }
        .reveal.revealed { opacity: 1; transform: translateY(0); }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-thumb { background: #222; }
        ::-webkit-scrollbar-track { background: #0a0a0a; }
      `}</style>

      {/* YouTube Music Player - Hidden */}
      {currentSong && isPlaying && (
        <div className="fixed -left-[9999px] -top-[9999px] w-1 h-1 overflow-hidden pointer-events-none">
          <iframe
            key={currentSong.id}
            ref={playerRef}
            width="1"
            height="1"
            src={`https://www.youtube.com/embed/${currentSong.id}?autoplay=1&controls=0&modestbranding=1&rel=0&enablejsapi=1`}
            title="Background Music"
            allow="autoplay"
            style={{ border: 0 }}
            onLoad={() => {
              // Play next song after current ends (approx 3-4 min)
              const timer = setTimeout(() => {
                const nextIdx = (songIndex + 1) % SONGS.length;
                setSongIndex(nextIdx);
                setCurrentSong(SONGS[nextIdx]);
                localStorage.setItem('rezka_song', JSON.stringify(SONGS[nextIdx]));
                localStorage.setItem('rezka_song_index', nextIdx.toString());
              }, 210000);
              return () => clearTimeout(timer);
            }}
          />
        </div>
      )}

      {/* Music Control */}
      {unlocked && currentSong && (
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="fixed bottom-5 right-5 z-50 w-11 h-11 rounded-full bg-[#111]/90 backdrop-blur border border-[#2a2a2a] hover:border-[#922b21] text-[#999] hover:text-[#e74c3c] grid place-items-center transition-all shadow-lg"
          aria-label={isPlaying ? 'Pause musik' : 'Putar musik'}
          title={isPlaying ? 'Matikan musik' : 'Nyalakan musik'}
        >
          <span className="text-[16px] leading-none">{isPlaying ? '♪' : '♫'}</span>
        </button>
      )}

      {/* Hero */}
      <section className="min-h-[100svh] flex flex-col items-center justify-center px-6 relative">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[640px] h-[640px] rounded-full opacity-[0.05] blur-3xl" style={{ background: 'radial-gradient(circle, #c0392b 0%, transparent 70%)' }} />
        </div>

        <div className="relative text-center max-w-[920px] reveal revealed">
          <p className="mono text-[10px] tracking-[0.32em] text-[#922b21] uppercase mb-10">
            UNTUK SESEORANG YANG NYATA
          </p>

          <h1 className="text-[clamp(48px,11vw,128px)] font-light leading-[0.88] tracking-[-0.02em] mb-8">
            Rezka
            <span className="block italic text-[#e74c3c] mt-1">Regina.</span>
          </h1>

          <p className="text-[18px] sm:text-[20px] font-light italic text-[#9a9a9a] max-w-[680px] mx-auto leading-[1.75]">
            Ini bukan puisi. Bukan film. Ini cuma saya, yang tidak tahu harus bilang apa selain — saya serius.
          </p>

          <div className="mt-16 flex flex-col items-center gap-5">
            <div className="h-px w-[72px] bg-[#922b21]/80" />
            <p className="mono text-[10px] tracking-[0.22em] text-[#444] uppercase">scroll</p>
          </div>
        </div>
      </section>

      {/* 01 */}
      <section className="px-6 py-24 sm:py-28 max-w-[720px] mx-auto reveal">
        <p className="mono text-[10px] tracking-[0.3em] text-[#922b21] uppercase mb-7">01 — Awal Mula</p>
        <h2 className="text-[32px] sm:text-[44px] font-light leading-[1.15] mb-10">
          Dimulai dari<br/><em className="text-[#e74c3c] italic">gangguan kecil</em>
        </h2>

        <div className="space-y-7 text-[17px] leading-[2.05] font-light text-[#cfcfcf]">
          <p>
            Jujur saja — awalnya saya yang <strong className="text-[#f0ebe5] font-normal">tidak tahu malu</strong>. Chat terus di Messenger, padahal Sayang mungkin hanya membalas karena sedang jualan dan saya kelihatan seperti calon pembeli. Tapi saya tidak beli apa-apa. Saya malah makin intens.
          </p>

          <div className="border-l-2 border-[#922b21] pl-5 py-1 my-9 text-[15px] italic text-[#eaeaea]">
            “Bayangkan seseorang yang mendekati kamu dengan energi ‘sales door-to-door’ tapi tidak pernah membeli produknya. Itu saya. Maaf, Gina.”
          </div>

          <p>
            Sayang sempat membatasi. Wajar. Tapi entah bagaimana — di antara semua yang datang dan pergi — pintu itu perlahan dibuka. Bukan karena saya istimewa. Mungkin karena saya <strong className="text-[#f0ebe5] font-normal">terlalu keras kepala untuk pergi</strong>.
          </p>

          <div className="my-11 p-5 bg-[#111] border border-[#1f1f1f] border-l-[3px] border-l-[#922b21]">
            <p className="mono text-[11px] tracking-wider text-[#666] uppercase mb-2">// catatan kecil</p>
            <p className="mono text-[12px] leading-relaxed text-[#a3a3a3]">
              Saya ingat betul rasanya membaca “iya” pertama kali setelah seminggu dibatasi. Seperti dapat nilai 100 untuk mata kuliah yang tidak pernah saya daftarkan.
            </p>
          </div>
        </div>
      </section>

      <div className="h-px w-[64px] bg-[#922b21]/70 mx-auto my-6 reveal" />

      {/* 02 */}
      <section className="px-6 py-24 sm:py-28 max-w-[720px] mx-auto reveal">
        <p className="mono text-[10px] tracking-[0.3em] text-[#922b21] uppercase mb-7">02 — Tentang Sayang</p>
        <h2 className="text-[32px] sm:text-[44px] font-light leading-[1.15] mb-10">
          Hal-hal yang<br/><em className="text-[#e74c3c] italic">membuat saya diam</em>
        </h2>

        <div className="space-y-7 text-[17px] leading-[2.05] font-light text-[#cfcfcf]">
          <p>
            Sayang orangnya lucu. Bukan lucu yang dipaksakan — lucu yang keluar begitu saja, absurd, tidak terduga, dan selalu berhasil membuat hal yang serius jadi terasa lebih ringan. Itu bukan kemampuan kecil. Itu <strong className="text-[#f0ebe5] font-normal">kekuatan</strong>.
          </p>
          <p>
            Sayang tahu bagaimana mendengarkan. Dan kalau sudah nyaman, bicara panjang malam-malam pun tidak terasa habis. Buktinya — saya yang harusnya tetap terjaga malah <strong className="text-[#f0ebe5] font-normal">tertidur di tengah telepon</strong>. Bukan karena bosan. Tapi karena suara Sayang itu tenang. Seperti rumah.
          </p>

          <div className="my-10 p-5 bg-[#111] border border-[#1f1f1f] border-l-[3px] border-l-[#922b21]">
            <p className="mono text-[11px] tracking-wider text-[#666] uppercase mb-2">// yang paling saya ingat</p>
            <p className="mono text-[12px] leading-relaxed text-[#a3a3a3]">
              Sayang pernah bilang sedang “mengerjain penipu sampai kena mental”. Absurd, tapi dari situ saya tahu: Sayang kuat. Kalau hidup pernah tidak baik, Sayang membalasnya dengan keberanian dan tawa, bukan dendam.
            </p>
          </div>

          <div className="border-l-2 border-[#922b21] pl-5 py-2 my-9 text-[20px] italic text-[#f0ebe5] leading-[1.7] font-light">
            “Orang yang bisa memaafkan bukan berarti tidak terluka. Justru sebaliknya — mereka tahu betapa beratnya luka itu, tapi tetap memilih untuk tidak membawanya terus.”
          </div>

          <p>
            Yang membuat saya benar-benar kagum: Sayang pernah menanggung hal-hal yang tidak ringan. Orang tua berpisah, kehilangan Ibu, Ayah yang memilih jalan lain. Tapi dari semua itu, Sayang tidak menjadi keras. <strong className="text-[#f0ebe5] font-normal">Pintu maaf itu tetap terbuka</strong>. Untuk Ayah yang tidak sempurna. Untuk hidup yang tidak adil.
          </p>
          <p>
            Dan di atas semua itu, Sayang mau <strong className="text-[#f0ebe5] font-normal">menuntun saya dalam proses belajar</strong>. Menerima saya apa adanya, sambil pelan-pelan menunjukkan arah yang lebih baik. Itu hal yang saya syukuri setiap hari.
          </p>
        </div>
      </section>

      {/* Carousel */}
      <section className="py-20 sm:py-24 bg-[#0f0f0f] border-y border-[#1a1a1a] reveal">
        <div className="max-w-[860px] mx-auto px-6">
          <div className="text-center mb-11">
            <p className="mono text-[10px] tracking-[0.3em] text-[#922b21] uppercase mb-5">03 — Foto Sayang</p>
            <h2 className="text-[28px] sm:text-[36px] font-light leading-tight">Yang membuat<br/><em className="text-[#e74c3c] italic">layar terasa hidup</em></h2>
          </div>

          <div className="relative max-w-[440px] mx-auto select-none">
            <div className="overflow-hidden bg-black border border-[#1c1c1c] p-[3px] touch-pan-y">
              <div 
                ref={trackRef}
                className="flex transition-transform duration-500 ease-[cubic-bezier(0.22,0.61,0.36,1)] will-change-transform"
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
                style={{ transform: `translateX(-${activePhoto * 100}%)` }}
              >
                {PHOTOS.map((photo, i) => (
                  <div key={i} className="min-w-full">
                    <div className="aspect-[3/4] relative bg-[#0a0a0a] overflow-hidden">
                      <img 
                        src={photo.url} 
                        alt={photo.alt}
                        className="w-full h-full object-cover"
                        loading={i === 0 ? 'eager' : 'lazy'}
                        decoding="async"
                        style={{ filter: 'grayscale(6%) contrast(1.04)', objectPosition: 'center 15%' }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-7 text-center px-3 min-h-[44px] flex items-center justify-center">
              <p key={activePhoto} className="text-[15px] italic font-light text-[#e8e8e8] leading-snug animate-[fadeIn_0.35s_ease]">
                “{PHOTOS[activePhoto].caption}”
              </p>
            </div>

            <div className="mt-8 flex items-center justify-center gap-7">
              <button 
                onClick={() => setActivePhoto((p) => (p - 1 + PHOTOS.length) % PHOTOS.length)}
                className="w-10 h-10 border border-[#2a2a2a] text-[#7a7a7a] hover:border-[#922b21] hover:text-[#e74c3c] transition-colors grid place-items-center"
                aria-label="Foto sebelumnya"
              >
                <span className="mono text-[14px] leading-none">←</span>
              </button>

              <div className="text-center">
                <div className="mono text-[10px] tracking-[0.18em] text-[#666] mb-2.5">
                  {String(activePhoto + 1).padStart(2, '0')} / {String(PHOTOS.length).padStart(2, '0')}
                </div>
                <div className="flex items-center justify-center gap-1.5">
                  {PHOTOS.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setActivePhoto(i)}
                      aria-label={`Ke foto ${i+1}`}
                      className={`h-[4px] rounded-full transition-all ${i === activePhoto ? 'w-6 bg-[#e74c3c]' : 'w-[4px] bg-[#333] hover:bg-[#555]'}`}
                    />
                  ))}
                </div>
              </div>

              <button 
                onClick={() => setActivePhoto((p) => (p + 1) % PHOTOS.length)}
                className="w-10 h-10 border border-[#2a2a2a] text-[#7a7a7a] hover:border-[#922b21] hover:text-[#e74c3c] transition-colors grid place-items-center"
                aria-label="Foto berikutnya"
              >
                <span className="mono text-[14px] leading-none">→</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 04 */}
      <section className="px-6 py-24 sm:py-28 max-w-[720px] mx-auto reveal">
        <p className="mono text-[10px] tracking-[0.3em] text-[#922b21] uppercase mb-7">04 — Tentang Saya</p>
        <h2 className="text-[32px] sm:text-[44px] font-light leading-[1.15] mb-10">
          Saya sedang<br/><em className="text-[#e74c3c] italic">mengusahakan</em>
        </h2>

        <div className="space-y-7 text-[17px] leading-[2.05] font-light text-[#cfcfcf]">
          <p>
            Saya tidak akan pura-pura semuanya mudah. Saat ini saya bekerja sebagai staf di Universitas Tadulako — P3K 2025 — dari pagi sampai malam. Di sisa waktu, saya merintis jasa fotografi, pembuatan website, dan editing. Masih kecil. Masih jatuh bangun.
          </p>
          <p>
            Di waktu yang sama, saya masih menjadi tumpuan untuk orang tua. Jadi kalau ada yang bertanya kenapa belum bergerak cepat — itulah jawabannya. <strong className="text-[#f0ebe5] font-normal">Bukan karena tidak mau. Tapi karena saya sedang menanggung banyak hal sekaligus.</strong>
          </p>

          <div className="my-11 p-5 bg-[#111] border border-[#1f1f1f] border-l-[3px] border-l-[#922b21]">
            <p className="mono text-[11px] tracking-wider text-[#666] uppercase mb-2">// catatan jujur</p>
            <p className="mono text-[12px] leading-relaxed text-[#a3a3a3]">
              Sigma ke Silae itu dekat. Satu kota. Kadang itu terasa lebih berat daripada LDR, karena tidak ada alasan geografis untuk menunda. Hanya waktu, tenaga, dan jadwal yang belum berpihak. Tapi saya sedang belajar mengelola semuanya.
            </p>
          </div>

          <p>
            Saya ingin Gina tahu: <strong className="text-[#f0ebe5] font-normal">keseriusan ini bukan sekadar kata</strong>. Saya sedang membangun, perlahan, dengan cara yang halal dan bertanggung jawab. Ada nama yang selalu ada di ujung semua usaha itu.
          </p>
        </div>
      </section>

      <div className="h-px w-[64px] bg-[#922b21]/70 mx-auto reveal" />

      {/* 05 */}
      <section className="px-6 py-28 sm:py-36 max-w-[900px] mx-auto text-center relative reveal">
        <div className="absolute inset-0 pointer-events-none opacity-[0.035]">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[520px] h-[520px] rounded-full blur-3xl" style={{ background: 'radial-gradient(circle, #c0392b 0%, transparent 70%)' }} />
        </div>

        <div className="relative">
          <p className="mono text-[10px] tracking-[0.3em] text-[#922b21] uppercase mb-10">05 — Penutup</p>

          <h2 className="text-[44px] sm:text-[68px] lg:text-[84px] font-light leading-[0.92] tracking-[-0.01em] mb-10">
            Sayang adalah<br/><em className="text-[#e74c3c] italic">yang terakhir.</em>
          </h2>

          <p className="text-[17px] sm:text-[19px] font-light italic text-[#a0a0a0] max-w-[680px] mx-auto leading-[1.9]">
            Bukan karena tidak ada pilihan lain. Tapi karena setelah mengenal Sayang — saya tidak mau ada pilihan lain. Saya ingin Rezka Regina menjadi wanita terakhir di hidup saya.
          </p>

          <div className="h-px w-12 bg-[#2a2a2a] mx-auto my-12" />

          <div className="space-y-2.5">
            <p className="mono text-[10px] tracking-[0.2em] text-[#5a5a5a] uppercase">Ditulis dengan serius, namun tangan sedikit gemetar</p>
            <p className="mono text-[13px] tracking-[0.14em] text-[#922b21] font-medium">MOH. RIFQI S. LAMADANG</p>
            <p className="mono text-[10px] text-[#444] tracking-wide">Sigma • Silae • Palu • 2025</p>
          </div>

          <div className="mt-14 flex flex-col items-center justify-center gap-3">
            {!showGift ? (
              <>
                <div className="flex flex-col sm:flex-row gap-3">
                  <a
                    href={`https://wa.me/${WA_NUMBER}?text=${encodeURIComponent('Saya sudah baca semuanya. Terima kasih, Rifqi. — Rezka Regina')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-7 py-3 bg-[#c0392b] hover:bg-[#d04434] text-white mono text-[11px] tracking-[0.18em] uppercase transition-colors"
                  >
                    Balas ke saya
                  </a>
                  <div className="relative inline-block">
                    <button
                      onClick={() => setShowGift(true)}
                      className="px-7 py-3 bg-[#111] border border-[#922b21] text-[#e74c3c] hover:bg-[#1a0a0a] mono text-[11px] tracking-[0.18em] uppercase transition-colors"
                    >
                      Kirim alamat untuk hadiah
                    </button>
                    {noCount < 10 && (
                      <button
                        onMouseEnter={() => {
                          const x = (Math.random() - 0.5) * 400;
                          const y = (Math.random() - 0.5) * 200;
                          setNoPos({ x, y });
                          setNoCount(c => c + 1);
                        }}
                        onMouseDown={(e) => {
                          e.preventDefault();
                          const x = (Math.random() - 0.5) * 400;
                          const y = (Math.random() - 0.5) * 200;
                          setNoPos({ x, y });
                          setNoCount(c => c + 1);
                        }}
                        onTouchStart={(e) => {
                          e.preventDefault();
                          const x = (Math.random() - 0.5) * 300;
                          const y = (Math.random() - 0.5) * 150;
                          setNoPos({ x, y });
                          setNoCount(c => c + 1);
                        }}
                        style={{ 
                          transform: `translate(${noPos.x}px, ${noPos.y}px)`,
                          position: 'fixed',
                          left: '50%',
                          bottom: '100px',
                          zIndex: 100,
                        }}
                        className="px-6 py-2 border border-[#333] bg-[#0a0a0a] text-[#555] mono text-[10px] tracking-[0.18em] uppercase transition-all duration-150 select-none touch-none whitespace-nowrap shadow-2xl"
                      >
                        {noCount > 6 ? 'Iya deh mau' : 'Tidak mau'}
                      </button>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => { localStorage.removeItem('rezka_unlocked'); localStorage.removeItem('rezka_song'); localStorage.removeItem('rezka_song_index'); location.reload(); }}
                  className="mt-2 text-[10px] text-[#444] hover:text-[#666] mono tracking-wider uppercase transition-colors"
                >
                  Kunci lagi
                </button>
              </>
            ) : (
              <div className="w-full max-w-[420px] p-6 bg-[#0f0f0f] border border-[#222] text-left">
                <p className="mono text-[10px] tracking-[0.2em] text-[#922b21] uppercase mb-4">Kirim Hadiah</p>
                <p className="text-[14px] text-[#bbb] mb-5 leading-relaxed" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
                  Saya ingin mengirim sesuatu ke Sayang. Bukan karena harus, tapi karena saya mau. Tulis alamat yang nyaman untuk menerima.
                </p>
                <div className="space-y-3">
                  <div>
                    <label className="mono text-[10px] text-[#666] uppercase tracking-wider">Alamat lengkap</label>
                    <textarea
                      value={giftAddress}
                      onChange={(e) => setGiftAddress(e.target.value)}
                      placeholder="Jl. ... Kel. ... Kec. Silae, Palu"
                      className="mt-1.5 w-full bg-[#0a0a0a] border border-[#2a2a2a] px-3 py-2.5 text-[13px] text-[#e0e0e0] placeholder-[#444] focus:outline-none focus:border-[#922b21] resize-none"
                      rows={3}
                      style={{ fontFamily: 'Space Mono, monospace' }}
                    />
                  </div>
                  <div>
                    <label className="mono text-[10px] text-[#666] uppercase tracking-wider">Catatan untuk kurir (opsional)</label>
                    <input
                      value={giftNote}
                      onChange={(e) => setGiftNote(e.target.value)}
                      placeholder="Rumah cat putih, pagar hitam"
                      className="mt-1.5 w-full bg-[#0a0a0a] border border-[#2a2a2a] px-3 py-2.5 text-[13px] text-[#e0e0e0] placeholder-[#444] focus:outline-none focus:border-[#922b21]"
                      style={{ fontFamily: 'Space Mono, monospace' }}
                    />
                  </div>
                </div>
                <div className="mt-5 flex gap-2.5">
                  <a
                    href={`https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(
                      `Alamat untuk hadiah:\n\n${giftAddress}${giftNote ? `\n\nCatatan: ${giftNote}` : ''}\n\n— Rezka`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => {
                      if (!giftAddress.trim()) {
                        alert('Isi alamatnya dulu ya, Sayang.');
                        return false;
                      }
                    }}
                    className={`flex-1 text-center px-5 py-2.5 mono text-[11px] tracking-[0.16em] uppercase transition-colors ${
                      giftAddress.trim() 
                        ? 'bg-[#c0392b] text-white hover:bg-[#d04434]' 
                        : 'bg-[#1a1a1a] text-[#555] pointer-events-none'
                    }`}
                  >
                    Kirim via WhatsApp
                  </a>
                  <button
                    onClick={() => setShowGift(false)}
                    className="px-4 py-2.5 border border-[#2a2a2a] text-[#777] hover:text-[#aaa] mono text-[11px] uppercase"
                  >
                    Batal
                  </button>
                </div>
                <p className="mt-3 mono text-[10px] text-[#3a3a3a]">Hanya saya yang bisa lihat. Tidak disimpan di website.</p>
              </div>
            )}
          </div>
        </div>
      </section>

      <footer className="border-t border-[#141414] py-8 px-6">
        <div className="max-w-[720px] mx-auto text-center">
          <p className="mono text-[10px] tracking-[0.2em] text-[#2a2a2a] uppercase">
            dibuat khusus · hanya untuk satu orang · 2025
          </p>
        </div>
      </footer>
    </div>
  );
}